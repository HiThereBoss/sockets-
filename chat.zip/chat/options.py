
COLORS = {'msg_sent': {'user': '#d9c6fd', 'msg': '#ebf1ff'}, 'msg_received': {'user': '#d9c6fd', 'msg': '#ebf1ff'}}

COLUMN = {'msg_sent': 2, 'msg_received': 1}

PACKING = {'msg_sent': {'side': 'right', 'user_anchor':'se', 'msg_anchor':'e'}, 'msg_received': {'side': 'left', 'user_anchor':'sw', 'msg_anchor':'w'}}

JUSTIFY = {'msg_sent': {'user': 'right', 'msg': 'left'}, 'msg_received': {'user': 'left', 'msg': 'left'}}